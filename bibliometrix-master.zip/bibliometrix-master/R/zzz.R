.onAttach<-function(...){
  packageStartupMessage("To cite bibliometrix in publications, please use:\n\nAria, M. & Cuccurullo, C. (2017) bibliometrix: An R-tool for comprehensive science mapping analysis, Journal of Informetrics, 11(4), pp 959-975, Elsevier.
                        \n\nhttp:\\\\www.bibliometrix.org\n
                        \nTo start with the shiny web-interface, please digit:
biblioshiny()\n")
}
